# 实体位置同步 Bug —— 排查说明（给外部 AI）

## 现象
- 让生物发生**垂直位移**（如玩家跳上去/顶住僵尸）后，本客户端渲染的实体会**稳定浮空或陷进地面**（约 ±0.4~0.7 格），且**不会自行恢复**。
- 同位置、同视角，**原版客户端显示完全正常**（贴地）。
- 服务器权威坐标（`/data get entity <id> Pos`，单机 integrated 之外的原版 Fabric 服务端）里，该僵尸 `Pos.y = 191.0`；而本客户端渲染的实体 Y 约为 `190.4`。
- 因此判断为**本客户端 bug**（原版正常、服务端权威正常，仅我们渲染/计算偏）。

## 已对照原版确认"一致"的环节（逐一核对过，非近似）
1. **AddEntity 包**字节序：`id(VarInt), uuid, type(VarInt), x/y/z(double), movement(LpVec3), xRot,yRot,yHeadRot(byte), data(VarInt)` —— 与 `src/Sharpcraft.Common/Network/EntityPackets.cs::TryReadAddEntity` 一致。
2. **Move 包（stepped）**：`id(VarInt), properties(VarInt: onGround=bit0, stepCount=properties>>>1)`；stepCount>0 时每步 `VarInt(ticks) + 3×short(/4096)`；stepCount<=0 时直接 3×short。与 `VecDelta.read` 一致（`TryReadVecDelta`）。大端已确认（`PayloadReader` 用 `ReadUInt16BigEndian`）。
3. **Teleport 包**：`id, PositionMoveRotation(Vec3 pos, Vec3 deltaMovement, yRot F32, xRot F32), relatives(INT bit0..8), onGround(BOOL)` —— 与 `TryReadTeleportEntity` 一致；`Relative` 用 bit0..4。**复现期间抓包无任何 teleport 包**。
4. **VecDeltaCodec 语义**：`absolute = decode(encode(base)+delta)`，delta==0 保持该轴；每包后 `base = end` —— 已按此实现（`EntityTracker.cs` 中 `CodecBaseX/Y/Z`）。
5. **插值**：原版 `LivingEntity.createInterpolationHandler() = SteppedInterpolationHandler`，**步进队列**（每包入队 step，`tickOffset=ticks`，每 tick 消费一份并 `setPos`；`interpolationSpeed` 平滑）。本仓 `EntityTracker.cs` 的 `EnqueueInterpolation / StepInterpolation / Advance` 为其移植。

## 关键实测（原始字节，已确认解码正确）
抓到的 `move_entity_pos` 原始 body（hex，去掉外层 length 后 `[id][properties][step: ticks + 3×short]`）示例：
- `01 03 03 0000 0000 0000` → id=1, stepCount=1, ticks=3, Δ=(0,0,0)（无害同步）
- `01 02 03 0000 08F8 0000` → Δ=(0, +0.561, 0)   （0x08F8=2296/4096）
- `01 02 03 0000 F607 0000` → Δ=(0, -0.625, 0)   （0xF607=-2559/4096）
- `01 02 03 0000 0129 0000` → Δ=(0, +0.073, 0)
- `01 02 03 0000 FD60 0000` → Δ=(0, -0.164, 0)
这些**确实是服务器发出的真实小增量**，且多为 `ticks=3` 的步进包；长期累加出现净漂移（我们观测到最终约 -0.6）。

## 疑点 / 待查
- 既然服务端权威 `Y=191.0` 恒定、且无 teleport，这些 ±0.5 的增量理论上应**相互抵消**并保持在 191.0（原版如此）。但本客户端把它们累加后**不再回到 191.0**。
- 重点怀疑：**多条重叠的 stepped 包在队列消费/base 推进时序**（我们可能在 `base` 或目标上重复/提前应用，导致净漂移）；以及移动包**分发/读取的边界**（是否有包被重复应用、或 Rot 包被误当 Pos 解析）。
- 渲染侧：`EntityModelMesher` 是否把脚底放在 `entity.Y`（此前诊断显示脚底世界 Y == entity.Y，但仍浮空——需复核该诊断所针对的实体 id 与真正陷地实体是否同一只）。

## 文件职责
- `EntityPackets.cs`：AddEntity/Move/Teleport 解码；`TryReadVecDelta`、`TryReadDeltaTriple`。
- `PayloadReader.cs`：大端读取。
- `ProtocolConstants.cs`：包 id（MoveEntityPos=54, PosRot=55, Rot=57）。
- `EntityTracker.cs`：`TrackedEntity`（X/Y/Z、PreviousY、Target、CodecBase、`_steps` 步进队列、`EnqueueInterpolation/StepInterpolation/Advance`、`ApplyMove/ApplyTeleport`、`Interpolate` 用 `Previous→Current` × alpha）。
- `TickLoop.cs`：固定 20Hz 累加器 + `Alpha`（partialTick）。
- `InteractiveSession.cs`：包分发（MoveEntityPos/PosRot/Rot、TeleportEntity），驱动 `_entities.Tick()` 与 `EntityStates(PartialTick)`。
- `EntityModelMesher.cs` / `EntityModelTransform.cs`：模型网格与实体级变换（`Translation=(X,Y,Z)`，模型脚底烘到 0）。
- `EntityAnimationState.cs` / `EntityPresentationState.cs`：`EntityRenderState`、`EntityAnimationFrame`、表现态。
- `docs/specs/network/entity-sync.md` 等：协议/变换规格。
- `EntityTrackerTests.cs`：相关单测。

## 期望
请指本客户端为何把上述真实 move 增量累加成稳定偏移（0.4~0.7 格）且不回归 191.0，给出与 `SteppedInterpolationHandler`/`VecDeltaCodec` 等效的正确实现要点或具体缺陷定位。
